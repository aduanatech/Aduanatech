# aranceles/views.py
import pandas as pd
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required

# Importamos Modelos y TODOS los Formularios
from .models import Arancel
from .forms import BusquedaArancelForm, ArancelForm, CargaMasivaForm, EliminarArancelForm
from .forms import BuscarCodigoForm

# ==========================================
#  SECCIÓN 1: PÚBLICA (Consultas y PDF)
# ==========================================

def buscar_arancel(request):
    """
    Vista pública para buscar aranceles.
    """
    form = BusquedaArancelForm(request.GET or None)
    resultados = []
    mensaje = ""

    if form.is_valid():
        query = form.cleaned_data['query']
        tipo = form.cleaned_data['tipo_busqueda']

        if query:
            if tipo == 'descripcion':
                resultados = Arancel.objects.filter(descripcion__icontains=query)
            elif tipo == 'capitulo':
                resultados = Arancel.objects.filter(codigo__startswith=query[:2])
            elif tipo == 'partida':
                resultados = Arancel.objects.filter(codigo__startswith=query[:4])
            elif tipo == 'sub_int':
                resultados = Arancel.objects.filter(codigo__startswith=query[:6])
            elif tipo == 'sub_reg':
                resultados = Arancel.objects.filter(codigo__startswith=query[:8])
            elif tipo == 'exacto':
                resultados = Arancel.objects.filter(codigo=query)

            if not resultados:
                mensaje = "No se encontraron resultados para su búsqueda."

    return render(request, 'aranceles/buscar.html', {
        'form': form,
        'resultados': resultados,
        'mensaje': mensaje
    })

def detalle_arancel(request, pk):
    arancel = get_object_or_404(Arancel, pk=pk)
    return render(request, 'aranceles/detalle.html', {'arancel': arancel})

def exportar_aranceles_pdf(request):
    query = request.GET.get('query', '')
    tipo = request.GET.get('tipo_busqueda', '')
    resultados = []

    if query and tipo:
        if tipo == 'descripcion':
            resultados = Arancel.objects.filter(descripcion__icontains=query)
        elif tipo == 'capitulo':
            resultados = Arancel.objects.filter(codigo__startswith=query[:2])
        elif tipo == 'partida':
            resultados = Arancel.objects.filter(codigo__startswith=query[:4])
        elif tipo == 'sub_int':
            resultados = Arancel.objects.filter(codigo__startswith=query[:6])
        elif tipo == 'sub_reg':
            resultados = Arancel.objects.filter(codigo__startswith=query[:8])
        elif tipo == 'exacto':
            resultados = Arancel.objects.filter(codigo=query)

    template_path = 'aranceles/pdf_template.html'
    context = {'resultados': resultados, 'query': query}

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="reporte_aranceles.pdf"'

    template = get_template(template_path)
    html = template.render(context)
    pisa_status = pisa.CreatePDF(html, dest=response)

    if pisa_status.err:
        return HttpResponse('Tuvimos errores al generar el PDF <pre>' + html + '</pre>')
    
    return response

# ==========================================
#  SECCIÓN 2: GESTIÓN ADMINISTRATIVA (CU-6)
# ==========================================

@staff_member_required
def menu_gestion_aranceles(request):
    """Menú principal con los 3 botones."""
    return render(request, 'aranceles/menu_gestion.html')

@staff_member_required
def crear_arancel(request):
    """Opción 1: Crear manualmente."""
    if request.method == 'POST':
        form = ArancelForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "¡Arancel creado exitosamente!")
            return redirect('menu_gestion')
    else:
        form = ArancelForm()
    return render(request, 'aranceles/gestion_crear.html', {'form': form})

@staff_member_required
def actualizar_masivo(request):
    """Opción 2: Carga masiva (Excel o CSV)."""
    if request.method == 'POST':
        form = CargaMasivaForm(request.POST, request.FILES)
        if form.is_valid():
            archivo = request.FILES['archivo']
            nombre_archivo = archivo.name.lower()
            
            try:
                # Detección de formato
                if nombre_archivo.endswith('.csv'):
                    df = pd.read_csv(archivo, engine='python', encoding='utf-8')
                elif nombre_archivo.endswith(('.xls', '.xlsx')):
                    df = pd.read_excel(archivo)
                else:
                    messages.error(request, "Formato no soportado. Use .csv o .xlsx")
                    return render(request, 'aranceles/gestion_actualizar.html', {'form': form})

                # Normalizar columnas a mayúsculas
                df.columns = [str(col).upper().strip() for col in df.columns]
                columnas_necesarias = ['CODIGO', 'DESCRIPCION', 'GRAVAMEN']
                
                if not all(col in df.columns for col in columnas_necesarias):
                    messages.error(request, f"Faltan columnas. El archivo debe tener: {', '.join(columnas_necesarias)}")
                    return render(request, 'aranceles/gestion_actualizar.html', {'form': form})

                contador = 0
                for index, row in df.iterrows():
                    codigo = str(row['CODIGO']).strip()
                    desc = str(row['DESCRIPCION']).strip()
                    grav = row['GRAVAMEN']

                    Arancel.objects.update_or_create(
                        codigo=codigo,
                        defaults={
                            'descripcion': desc,
                            'gravamen': grav,
                            
                        }
                    )
                    contador += 1
                
                messages.success(request, f'Se procesaron {contador} aranceles correctamente.')
                return redirect('menu_gestion')

            except Exception as e:
                messages.error(request, f"Error al leer el archivo: {e}")
    else:
        form = CargaMasivaForm()

    return render(request, 'aranceles/gestion_actualizar.html', {'form': form})

@staff_member_required
def eliminar_arancel(request):
    """Opción 3: Eliminar por código."""
    arancel_encontrado = None
    
    if request.method == 'POST':
        if 'confirmar_eliminar' in request.POST:
            pk = request.POST.get('pk_eliminar')
            arancel = get_object_or_404(Arancel, pk=pk)
            codigo_borrado = arancel.codigo
            arancel.delete()
            messages.success(request, f"El arancel {codigo_borrado} fue eliminado.")
            return redirect('menu_gestion')
            
        form = EliminarArancelForm(request.POST)
        if form.is_valid():
            codigo = form.cleaned_data['codigo']
            try:
                arancel_encontrado = Arancel.objects.get(codigo=codigo)
            except Arancel.DoesNotExist:
                messages.error(request, f"No existe ningún arancel con el código {codigo}")
    else:
        form = EliminarArancelForm()

    return render(request, 'aranceles/gestion_eliminar.html', {
        'form': form, 
        'arancel': arancel_encontrado
    })
    
@staff_member_required
def buscar_para_editar(request):
    """Paso 1: Pantalla para buscar qué código queremos corregir"""
    if request.method == 'POST':
        form = BuscarCodigoForm(request.POST)
        if form.is_valid():
            codigo = form.cleaned_data['codigo']
            try:
                # Buscamos si existe
                arancel = Arancel.objects.get(codigo=codigo)
                # Si existe, nos vamos a la pantalla de edición de ese ID específico
                return redirect('realizar_edicion', pk=arancel.pk)
            except Arancel.DoesNotExist:
                messages.error(request, f"No se encontró el código {codigo}")
    else:
        form = BuscarCodigoForm()
    
    return render(request, 'aranceles/gestion_buscar_editar.html', {'form': form})

@staff_member_required
def realizar_edicion(request, pk):
    """Paso 2: Formulario con los datos cargados para corregirlos"""
    arancel = get_object_or_404(Arancel, pk=pk)
    
    if request.method == 'POST':
        # Cargamos el formulario con los datos nuevos (POST) sobre la instancia existente
        form = ArancelForm(request.POST, instance=arancel)
        if form.is_valid():
            form.save()
            messages.success(request, f"¡El arancel {arancel.codigo} fue modificado exitosamente!")
            return redirect('menu_gestion')
    else:
        # Cargamos el formulario con los datos actuales de la base de datos
        form = ArancelForm(instance=arancel)
    
    return render(request, 'aranceles/gestion_editar.html', {
        'form': form, 
        'arancel': arancel
    })