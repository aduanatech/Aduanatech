# aranceles/forms.py
from django import forms
from .models import Arancel

# 1. FORMULARIO DEL BUSCADOR (Público)
class BusquedaArancelForm(forms.Form):
    OPCIONES_BUSQUEDA = [
        ('descripcion', 'Nombre / Descripción del producto'),
        ('capitulo', 'Capítulo (2 dígitos)'),
        ('partida', 'Partida (4 dígitos)'),
        ('sub_int', 'Subpartida Internacional (6 dígitos)'),
        ('sub_reg', 'Subpartida Regional (8 dígitos)'),
        ('exacto', 'Código Nacional Completo (10 dígitos)'),
    ]

    query = forms.CharField(
        label='Criterio de búsqueda', 
        max_length=100, 
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese código o texto...'})
    )
    tipo_busqueda = forms.ChoiceField(
        label='Buscar por', 
        choices=OPCIONES_BUSQUEDA, 
        widget=forms.Select(attrs={'class': 'form-select'})
    )

# 2. FORMULARIO PARA CREAR/EDITAR (Manual)
class ArancelForm(forms.ModelForm):
    class Meta:
        model = Arancel
        # Nota: Ya quitamos 'iva' de aquí
        fields = ['codigo', 'descripcion', 'gravamen']
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 3}),
        }

# 3. FORMULARIO PARA CARGA MASIVA
class CargaMasivaForm(forms.Form):
    archivo = forms.FileField(
        label='Selecciona el archivo (.xlsx o .csv)',
        help_text='Soporta Excel y CSV (separado por comas o punto y coma).'
    )

# 4. FORMULARIO PARA ELIMINAR
class EliminarArancelForm(forms.Form):
    codigo = forms.CharField(label='Código del Arancel a Eliminar', max_length=20)

class BuscarCodigoForm(forms.Form):
    codigo = forms.CharField(
        label='Ingrese el Código del Arancel a Modificar', 
        max_length=20,
        widget=forms.TextInput(attrs={'placeholder': 'Ej: 0101.21.00'})
    )