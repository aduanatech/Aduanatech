# aranceles/models.py
from django.db import models

class Arancel(models.Model):
    codigo = models.CharField(max_length=20, unique=True, verbose_name="Código Arancelario")
    descripcion = models.TextField(verbose_name="Descripción")
    gravamen = models.DecimalField(max_digits=5, decimal_places=2, verbose_name="Gravamen (%)")
    
    def __str__(self):
        return f"{self.codigo} - {self.descripcion[:50]}..."
    